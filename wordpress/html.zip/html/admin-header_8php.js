var admin_header_8php =
[
    [ "$admin_body_class", "admin-header_8php.html#a78c97e88e425a1b47a91284e712e7c1d", null ],
    [ "$admin_body_classes", "admin-header_8php.html#a6c56a3baaeeb7d93346d68600e1f6018", null ],
    [ "$admin_title", "admin-header_8php.html#a0b9465afe9cfa8ab7674fb75b92326a0", null ],
    [ "$current_screen", "admin-header_8php.html#a69da619c66502d0b3d31d36e0096bdd9", null ],
    [ "$hook_suffix", "admin-header_8php.html#a9a1c1ccdd50914065ed8e0a096a22822", null ],
    [ "$pagenow", "admin-header_8php.html#a226a8c35ebe8d3d1d1cc57b01677223b", null ],
    [ "$parent_file", "admin-header_8php.html#acc9d6765dbc01fb971d046a8e2555dba", null ],
    [ "$title", "admin-header_8php.html#ada57e7bb7c152edad18fe2f166188691", null ],
    [ "$total_update_count", "admin-header_8php.html#aaa4bc3c864a9fc0c2fa6fc86ca8a5023", null ],
    [ "$update_title", "admin-header_8php.html#a65be54e8ea7165beff8b17473283844a", null ],
    [ "$wp_locale", "admin-header_8php.html#aaba5e23491b8d38c1923f129c959e3b8", null ],
    [ "else", "admin-header_8php.html#afd8f9f00aa0b328b321823ef5524f240", null ],
    [ "if", "admin-header_8php.html#a3b5e8cfd8b86749442cb35a7d3c6edba", null ]
];