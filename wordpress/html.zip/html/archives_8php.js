var archives_8php =
[
    [ "register_block_core_archives", "archives_8php.html#a3f7428e4f525162260276e13ae5dd713", null ],
    [ "render_block_core_archives", "archives_8php.html#a811fda6e41266ddf8dd17d6123358369", null ]
];