var category_8php =
[
    [ "_make_cat_compat", "category_8php.html#afec81cc47ed27857af71edfe82ed5856", null ],
    [ "cat_is_ancestor_of", "category_8php.html#a0c684d470aa492ea30f0abe46ec2ff24", null ],
    [ "clean_category_cache", "category_8php.html#a4a892bccc9bd0e08879e1f2529941086", null ],
    [ "get_cat_ID", "category_8php.html#a406a5840c85232a8daac9ff8889a0fbe", null ],
    [ "get_cat_name", "category_8php.html#a6bb77c55bbfddd64e6f8d9089300e635", null ],
    [ "get_categories", "category_8php.html#aed7863fcda588b410a7522251a169332", null ],
    [ "get_category", "category_8php.html#a8804563f89424e7863f3c07ffd913ae4", null ],
    [ "get_category_by_path", "category_8php.html#af08eb5ed8ea04e2a87872bb8ca27f617", null ],
    [ "get_category_by_slug", "category_8php.html#a7befdfd978cb387752cd5f4c19d04f71", null ],
    [ "get_tag", "category_8php.html#a66f81d0595f3cc2d095cc8785c0ad857", null ],
    [ "get_tags", "category_8php.html#a618a0d118506f31933b68cb033d25812", null ],
    [ "sanitize_category", "category_8php.html#a61bd46680620d19bcf8b8871c8c27464", null ],
    [ "sanitize_category_field", "category_8php.html#a72aec90326ad95a983f80323c0c3ca79", null ]
];