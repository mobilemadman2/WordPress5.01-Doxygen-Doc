var cache_8php =
[
    [ "WP_Object_Cache", "class_w_p___object___cache.html", "class_w_p___object___cache" ],
    [ "wp_cache_add", "cache_8php.html#abe3333465ad7cc01d1aa86db955c8423", null ],
    [ "wp_cache_add_global_groups", "cache_8php.html#a24d1a73912c54da5a9bf2931dea4e47b", null ],
    [ "wp_cache_add_non_persistent_groups", "cache_8php.html#a4ea36e8e2880b2b76f3c85548a052ae4", null ],
    [ "wp_cache_close", "cache_8php.html#aa502c68f2ad71cec9cb3b7d39ed78616", null ],
    [ "wp_cache_decr", "cache_8php.html#af64bda141702c2d0835f50e7d4eecb37", null ],
    [ "wp_cache_delete", "cache_8php.html#ad10b001104cf1a51a9092c13248e3610", null ],
    [ "wp_cache_flush", "cache_8php.html#af4c681a8e4a0681345e7eec841780af6", null ],
    [ "wp_cache_get", "cache_8php.html#ab959dd4d87319053af3f7fd00817c246", null ],
    [ "wp_cache_incr", "cache_8php.html#a41d6bfe77f5b0d43648ff9bb35ce4a2b", null ],
    [ "wp_cache_init", "cache_8php.html#adfff7f29d2eca9834839e0af19fad239", null ],
    [ "wp_cache_replace", "cache_8php.html#ada1d84a724eb9360928968a963abb18e", null ],
    [ "wp_cache_reset", "cache_8php.html#a165fc2b269e2aca287551b63ebe5f8d4", null ],
    [ "wp_cache_set", "cache_8php.html#a7180b8139e1a5755b50a2d22841f3c5a", null ],
    [ "wp_cache_switch_to_blog", "cache_8php.html#aa7dab8a09d14d51111fb1bd9a53a36ab", null ]
];