var about_8php =
[
    [ "enableFixedHeaders", "about_8php.html#a52e44f6fff0fb0ae398d0024456114e8", null ],
    [ "setup", "about_8php.html#a8ce0562bbcb73408bc94a49949ca0e19", null ],
    [ "$sections", "about_8php.html#af9c7748a0bb6982702f5fc917e88fa2e", null ],
    [ "$title", "about_8php.html#ada57e7bb7c152edad18fe2f166188691", null ],
    [ "adjustScrollPosition", "about_8php.html#abcfcc5d1ffb9b4e8119ea2e855ed663e", null ],
    [ "endif", "about_8php.html#ab4d017bcc79cd2827c3dce8af2570e91", null ],
    [ "jQuery", "about_8php.html#a2b1d6f9c448e3ce72f4e1865d6e38d2c", null ],
    [ "offset", "about_8php.html#a7a229a4786deeddd59c6091247a8c8a6", null ],
    [ "return", "about_8php.html#a9717e7bbecb906637e86cef6da3d83c2", null ]
];