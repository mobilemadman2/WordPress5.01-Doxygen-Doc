var capabilities_8php =
[
    [ "add_role", "capabilities_8php.html#adab18b95af6646f2c6a98ec379db4f66", null ],
    [ "author_can", "capabilities_8php.html#a1524fff210993a38125373c431bb7aed", null ],
    [ "current_user_can", "capabilities_8php.html#a145219199b597010f95137f185e10d4d", null ],
    [ "current_user_can_for_blog", "capabilities_8php.html#a512a92db3fbe8e2cf9da816e9550e069", null ],
    [ "get_role", "capabilities_8php.html#a5fc9412bdd3674e505cddc93eb7dd305", null ],
    [ "get_super_admins", "capabilities_8php.html#a20a8cdbbf2aaa0602380af667f5e6839", null ],
    [ "grant_super_admin", "capabilities_8php.html#a9ff7ad364b16516a7ec79e0c612dda51", null ],
    [ "is_super_admin", "capabilities_8php.html#ad6315ac0163ba6009b52df706a43c14d", null ],
    [ "map_meta_cap", "capabilities_8php.html#aadb97fa1a68505b98910638a70d5b035", null ],
    [ "remove_role", "capabilities_8php.html#a0d4adc3743bce801715388949e231a6d", null ],
    [ "revoke_super_admin", "capabilities_8php.html#abf8eb42477223a0353856a51422f8aca", null ],
    [ "user_can", "capabilities_8php.html#a35ab92fa9e93526f3f4bb67785eabc22", null ],
    [ "wp_maybe_grant_install_languages_cap", "capabilities_8php.html#af80307761c45efb91458d5326e3a5bdf", null ],
    [ "wp_roles", "capabilities_8php.html#a8c86f267da09c8b69f85e8a53614bd06", null ]
];