var categories_8php =
[
    [ "build_dropdown_script_block_core_categories", "categories_8php.html#afa823e2045b8ad44300f34c8f4547414", null ],
    [ "register_block_core_categories", "categories_8php.html#aea8c9db0a95b926571d5d67dc12edae9", null ],
    [ "render_block_core_categories", "categories_8php.html#aa4b278cd07ec51cf0eb2323d02800ed9", null ]
];