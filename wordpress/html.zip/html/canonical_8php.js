var canonical_8php =
[
    [ "_remove_qs_args_if_not_in_url", "canonical_8php.html#a9b8dd4f137fbe065c87e2709f831fafc", null ],
    [ "redirect_canonical", "canonical_8php.html#ac72e11d1143bf6e88ce45ea6bc20cba5", null ],
    [ "redirect_guess_404_permalink", "canonical_8php.html#a9a75746f73dbf8766a55c835d800f059", null ],
    [ "strip_fragment_from_url", "canonical_8php.html#abe6604611edd7f28d2fc5dc4d7ced514", null ],
    [ "wp_redirect_admin_locations", "canonical_8php.html#add4d7f80d47d8051b777634366b68a39", null ]
];