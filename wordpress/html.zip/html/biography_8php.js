var biography_8php =
[
    [ "$author_bio_avatar_size", "biography_8php.html#a7dc2415e2abcc1015dfa05b24bb5cbd5", null ]
];