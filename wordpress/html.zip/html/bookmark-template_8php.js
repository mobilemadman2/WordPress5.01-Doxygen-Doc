var bookmark_template_8php =
[
    [ "_walk_bookmarks", "bookmark-template_8php.html#a43146baa714cc48ed84e9b7f953f1534", null ],
    [ "wp_list_bookmarks", "bookmark-template_8php.html#a450d25d8ed83be2786a54f01735e051d", null ]
];