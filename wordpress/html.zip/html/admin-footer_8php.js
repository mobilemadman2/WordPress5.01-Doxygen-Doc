var admin_footer_8php =
[
    [ "$hook_suffix", "admin-footer_8php.html#a9a1c1ccdd50914065ed8e0a096a22822", null ],
    [ "$text", "admin-footer_8php.html#adf95f30eaafccead90ab5e2cdb55e9b9", null ]
];