var admin_ajax_8php =
[
    [ "$core_actions_get", "admin-ajax_8php.html#a1e184cd69f73b523c385309696e82ca2", null ],
    [ "$core_actions_post", "admin-ajax_8php.html#a9cfe1ccd83f40d2111c4a11ea131287a", null ],
    [ "$core_actions_post_deprecated", "admin-ajax_8php.html#a1d656c5ecca6b87260b8f3348c18626b", null ],
    [ "DOING_AJAX", "admin-ajax_8php.html#a0597550ce673ad79c507bfa03dcf0ef4", null ],
    [ "else", "admin-ajax_8php.html#a8d42525897d9dd0c69ce4bed62cf3985", null ],
    [ "if", "admin-ajax_8php.html#af2e00ddd668781baf5e16cd81273982a", null ],
    [ "if", "admin-ajax_8php.html#a1aab8c243965ca8358babd0757aae36b", null ],
    [ "str_replace", "admin-ajax_8php.html#ac4fff5994584748153863eb28b9d5152", null ],
    [ "str_replace", "admin-ajax_8php.html#a0d80dd3afef4278106c5b2f2fc56e5dc", null ]
];