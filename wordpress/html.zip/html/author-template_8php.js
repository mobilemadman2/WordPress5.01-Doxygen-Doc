var author_template_8php =
[
    [ "__clear_multi_author_cache", "author-template_8php.html#a9652ab2c17a957c192cc0e8c66a4f2e6", null ],
    [ "get_author_posts_url", "author-template_8php.html#a4f5d74fbf88fc88125e031ac593f92c7", null ],
    [ "get_the_author", "author-template_8php.html#a390b3006a3c04275068496e7ecd9f380", null ],
    [ "get_the_author_link", "author-template_8php.html#ae2b3d0ab793cd67378bca293d1dcc078", null ],
    [ "get_the_author_meta", "author-template_8php.html#a148662b76a73eb05ffa2d851d7be62f2", null ],
    [ "get_the_author_posts", "author-template_8php.html#a327b7bff1563d72add16686ec5ee07ef", null ],
    [ "get_the_author_posts_link", "author-template_8php.html#aa3ce51f82aa965ebdd079e55bc3d126c", null ],
    [ "get_the_modified_author", "author-template_8php.html#a23eacff76301893fcdcbcd115d86e95c", null ],
    [ "is_multi_author", "author-template_8php.html#ac1a1d03450f6e5043b74ab8f805c6810", null ],
    [ "the_author", "author-template_8php.html#abe5a28e4762342ca5b9d21ad52945d8a", null ],
    [ "the_author_link", "author-template_8php.html#a76fade4e285a9bc544c8d9913794498d", null ],
    [ "the_author_meta", "author-template_8php.html#a24ea2578348d6af45eaa11d1da765a09", null ],
    [ "the_author_posts", "author-template_8php.html#a540573bab52ca4f0a4a8e96c390a59b0", null ],
    [ "the_author_posts_link", "author-template_8php.html#ae6ab5efdbcf44f6b098b86734e92bf5e", null ],
    [ "the_modified_author", "author-template_8php.html#a61142f428e85673e42bed756bdb365cd", null ],
    [ "wp_list_authors", "author-template_8php.html#a8b06fde48aeda0699faf8c60ec226580", null ]
];