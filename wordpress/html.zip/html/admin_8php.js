var admin_8php =
[
    [ "$date_format", "admin_8php.html#acca3fdcdfc67e06cb49a87e476d364a8", null ],
    [ "$editing", "admin_8php.html#a89f81e1f57ac61488a8dc6a7ab773bd2", null ],
    [ "$hook_suffix", "admin_8php.html#af8423cd5af81e3dcfaddabc8f2fb940e", null ],
    [ "$page_hook", "admin_8php.html#aa5146fc3b8a2a571207c02cd3db6bdbc", null ],
    [ "$pagenow", "admin_8php.html#acf8f3d085c7f1a863f2a32620b8e9ebc", null ],
    [ "$plugin_page", "admin_8php.html#a891798d22af50f07848e90e89626d455", null ],
    [ "$taxnow", "admin_8php.html#a32ce21a7fe04f6a91fb214cf675e1c73", null ],
    [ "$time_format", "admin_8php.html#a96745a88c8a49f8ed93ec24fa13619cb", null ],
    [ "$typenow", "admin_8php.html#afdab095b84970d9e7de6a349d64d4b04", null ],
    [ "$wp_importers", "admin_8php.html#a6a933a0b300f5f49d16d81088b552528", null ],
    [ "else", "admin_8php.html#abbbeba4b82f0f3cb0c958fa6dbd773ae", null ],
    [ "elseif", "admin_8php.html#a58eedc1b5eccfbdb8c1565d91e9e79cf", null ],
    [ "false", "admin_8php.html#a008f12f6dcbb8fb6f37ccdb88af61f7e", null ],
    [ "if", "admin_8php.html#a7755bc704347fc38eb5344f95be8a912", null ],
    [ "true", "admin_8php.html#a248cc56a489f108623a9260ea85bded3", null ]
];