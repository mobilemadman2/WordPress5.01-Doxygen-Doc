var class_wp_importer_8php =
[
    [ "WP_Importer", "class_w_p___importer.html", "class_w_p___importer" ],
    [ "get_cli_args", "class-wp-importer_8php.html#aa80597e3a6326cbd41d900539194be4e", null ]
];