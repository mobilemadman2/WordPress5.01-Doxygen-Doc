var blocks_8php =
[
    [ "_restore_wpautop_hook", "blocks_8php.html#abc429bc386ad15e8edfa130d960b25fb", null ],
    [ "block_version", "blocks_8php.html#a7cd07b85ecfaedebc87a436c1e41efbf", null ],
    [ "do_blocks", "blocks_8php.html#a5c7993bbaf199561c346f8b150ca2766", null ],
    [ "excerpt_remove_blocks", "blocks_8php.html#a91ad13cb5b80431f3d46f57f8a2647a8", null ],
    [ "get_dynamic_block_names", "blocks_8php.html#a11e7a95d8e118126e9074293254487df", null ],
    [ "has_block", "blocks_8php.html#a961751d0bbbdc8ea32c0e76ec566c14d", null ],
    [ "has_blocks", "blocks_8php.html#ae1227e929890d18254a4bdfe1cfb3acc", null ],
    [ "parse_blocks", "blocks_8php.html#ab3c89eb73ec2eff9072845b34296f7a2", null ],
    [ "register_block_type", "blocks_8php.html#ad0ed9b03f4783426a5c41739e3b1f14d", null ],
    [ "render_block", "blocks_8php.html#a7fb177ba7e6c9415992f510693994790", null ],
    [ "unregister_block_type", "blocks_8php.html#a8ee12dd954947fccfa439be03eda0478", null ]
];