var akismet_8php =
[
    [ "AKISMET__MINIMUM_WP_VERSION", "akismet_8php.html#ad4fa1b1681ee4edf8b927a8656564322", null ],
    [ "AKISMET__PLUGIN_DIR", "akismet_8php.html#a56390d7a799d08899d1c1f381e9a900f", null ],
    [ "AKISMET_DELETE_LIMIT", "akismet_8php.html#aeddda4b824c7290b32455a14655d1764", null ],
    [ "AKISMET_VERSION", "akismet_8php.html#a105362de79c0d42d9b8f20a33eb6b95b", null ],
    [ "if", "akismet_8php.html#ac342d921b02b504fcd5d054c4c42f2ba", null ]
];